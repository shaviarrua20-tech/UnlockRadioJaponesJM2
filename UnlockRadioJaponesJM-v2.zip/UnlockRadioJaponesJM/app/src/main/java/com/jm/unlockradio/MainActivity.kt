package com.jm.unlockradio

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF070A0D)
private val Card = Color(0xFF151B20)
private val Red = Color(0xFFFF1F2D)
private val Muted = Color(0xFF9BA7B1)

data class RadioModel(val name: String, val brand: String = "Toyota")
private val models = listOf(
    "NSZT-W62G", "NSZT-W68T", "NSZT-Y68T", "NSLN-W68", "NSZN-W68T", "NSZT-W66T",
    "NSCD-W66", "NSZT-W64", "NSZN-W64T", "NSCP-W62", "NSZT-W61G",
    "NSCT-W61", "NSDN-W60", "NHZN-W60G", "NHDT-W59", "NHDT-W58"
).map { RadioModel(it) }

enum class Screen { HOME, MODELS, GUIDE, ERC, RESULT, HISTORY }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var selected by remember { mutableStateOf(models.first()) }
    var erc by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }
    val history = remember { mutableStateListOf<Pair<String, String>>() }
    MaterialTheme(colorScheme = darkColorScheme(primary = Red, background = Bg, surface = Card)) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            when (screen) {
                Screen.HOME -> Home({ screen = Screen.MODELS }, { screen = Screen.HISTORY })
                Screen.MODELS -> Models { selected = it; screen = Screen.GUIDE }
                Screen.GUIDE -> Guide(selected) { screen = Screen.ERC }
                Screen.ERC -> ErcEntry(selected, erc, { erc = it }, { screen = Screen.RESULT })
                Screen.RESULT -> ResultScreen(selected, erc, result, { result = it }, {
                    if (erc.isNotBlank() && result.isNotBlank()) history.add(0, erc to result)
                    erc = ""; result = ""; screen = Screen.MODELS
                })
                Screen.HISTORY -> History(history) { screen = Screen.HOME }
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String? = null) {
    Column(Modifier.fillMaxWidth().padding(24.dp)) {
        Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 28.sp)
        subtitle?.let { Spacer(Modifier.height(6.dp)); Text(it, color = Muted) }
    }
}

@Composable
fun Home(onStart: () -> Unit, onHistory: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("🔓", fontSize = 72.sp)
        Spacer(Modifier.height(18.dp))
        Text("UNLOCK RADIO\nJAPONÉS JM", color = Color.White, fontWeight = FontWeight.Black, fontSize = 34.sp, lineHeight = 36.sp)
        Spacer(Modifier.height(12.dp))
        Text("Guías para radios japonesas y acceso rápido a ERC Calc.", color = Muted, fontSize = 17.sp)
        Spacer(Modifier.height(36.dp))
        Button(onClick = onStart, modifier = Modifier.fillMaxWidth().height(56.dp), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Comenzar", fontWeight = FontWeight.Bold) }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = onHistory, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("Historial") }
    }
}

@Composable
fun Models(onSelect: (RadioModel) -> Unit) {
    var q by remember { mutableStateOf("") }
    Column {
        Header("Selecciona el modelo", "Busca el modelo exacto que aparece en tu radio")
        OutlinedTextField(q, { q = it }, label = { Text("Buscar modelo") }, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp), singleLine = true)
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.padding(horizontal = 20.dp)) {
            items(models.filter { it.name.contains(q, true) }) { m ->
                Card(Modifier.fillMaxWidth().padding(vertical = 5.dp).clickable { onSelect(m) }, colors = CardDefaults.cardColors(containerColor = Card)) {
                    Column(Modifier.padding(18.dp)) { Text(m.name, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp); Text(m.brand, color = Muted) }
                }
            }
        }
    }
}

@Composable
fun Guide(model: RadioModel, next: () -> Unit) {
    val isW62G = model.name == "NSZT-W62G"
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Header(model.name, if (isW62G) "Tutorial real — obtener el ERC" else "Guía para localizar el ERC")
        if (isW62G) {
            GuidePhoto(R.drawable.w62g_entry, "1. Mantén presionada la perilla MENU durante aproximadamente 2 segundos y luego suéltala. Toca alternadamente los dos puntos señalados en la imagen (superior → inferior → superior → inferior) varias veces hasta abrir el menú de servicio.")
            GuidePhoto(R.drawable.w62g_service, "2. En el menú de servicio entra en Información de servicio.")
            GuidePhoto(R.drawable.w62g_service_info, "3. Selecciona la opción de entrada del código de seguridad para llegar a la pantalla ERC.")
            GuidePhoto(R.drawable.w62g_erc, "4. Copia exactamente los 16 caracteres hexadecimales que aparecen en la pantalla ERC.")
        } else {
            Card(Modifier.fillMaxWidth().padding(20.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
                Column(Modifier.padding(20.dp)) {
                    Text("Guía en preparación", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("Este modelo todavía no tiene un tutorial fotográfico verificado. No uses instrucciones de otro modelo.", color = Muted)
                }
            }
        }
        Button(next, Modifier.fillMaxWidth().padding(20.dp).height(54.dp), enabled = isW62G, colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Ingresar ERC") }
    }
}

@Composable
fun GuidePhoto(drawable: Int, caption: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
        Column {
            Image(painterResource(drawable), null, Modifier.fillMaxWidth().heightIn(max = 360.dp), contentScale = ContentScale.FillWidth)
            Text(caption, color = Color.White, modifier = Modifier.padding(16.dp), lineHeight = 21.sp)
        }
    }
}

@Composable
fun ErcEntry(model: RadioModel, value: String, set: (String) -> Unit, next: () -> Unit) {
    val context = LocalContext.current
    val clean = value.uppercase().filter { it in '0'..'9' || it in 'A'..'F' }.take(16)
    Column {
        Header("Ingresa el código ERC", model.name)
        OutlinedTextField(clean, { set(it.uppercase().filter { c -> c in '0'..'9' || c in 'A'..'F' }.take(16)) }, label = { Text("ERC de 16 caracteres") }, supportingText = { Text("${clean.length}/16") }, keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Characters), modifier = Modifier.fillMaxWidth().padding(20.dp), singleLine = true)
        Button(onClick = { copy(context, clean); launchErcCalc(context) }, enabled = clean.length == 16, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Copiar ERC y abrir ERC Calc") }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = next, enabled = clean.length == 16, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(52.dp)) { Text("Ya tengo el resultado") }
        Text("La primera versión no copia ni modifica ERC Calc: abre la app instalada para realizar el cálculo.", color = Muted, modifier = Modifier.padding(20.dp))
    }
}

@Composable
fun ResultScreen(model: RadioModel, erc: String, result: String, setResult: (String) -> Unit, reset: () -> Unit) {
    val context = LocalContext.current
    val clean = result.uppercase().filter { it.isLetterOrDigit() }.take(8)
    Column {
        Header("Código de desbloqueo", model.name)
        Text("ERC: $erc", color = Muted, modifier = Modifier.padding(horizontal = 20.dp))
        OutlinedTextField(clean, { setResult(it.uppercase().filter { c -> c.isLetterOrDigit() }.take(8)) }, label = { Text("Resultado de ERC Calc") }, supportingText = { Text("${clean.length}/8") }, modifier = Modifier.fillMaxWidth().padding(20.dp), singleLine = true)
        Button(onClick = { copy(context, clean) }, enabled = clean.length == 8, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).height(54.dp), colors = ButtonDefaults.buttonColors(containerColor = Red)) { Text("Copiar código") }
        Spacer(Modifier.height(18.dp))
        Card(Modifier.fillMaxWidth().padding(20.dp), colors = CardDefaults.cardColors(containerColor = Card)) {
            Column(Modifier.padding(18.dp)) {
                Text("Paso final", color = Color.White, fontWeight = FontWeight.Bold)
                if (model.name == "NSZT-W62G") {
                    Image(painterResource(R.drawable.w62g_erc), null, Modifier.fillMaxWidth().padding(top = 10.dp), contentScale = ContentScale.FillWidth)
                    Text("Escribe el código de 8 caracteres en el campo blanco inferior. Luego pulsa el botón inferior derecho 「完了」 (Finalizar/OK). La radio aceptará el código y se reiniciará automáticamente.", color = Muted, modifier = Modifier.padding(top = 10.dp))
                } else {
                    Text("Introduce el código en la pantalla de desbloqueo de tu radio y confirma según las indicaciones de la unidad.", color = Muted, modifier = Modifier.padding(top = 8.dp))
                }
            }
        }
        OutlinedButton(onClick = reset, enabled = clean.length == 8, modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp)) { Text("Guardar y nuevo cálculo") }
    }
}

@Composable
fun History(items: List<Pair<String,String>>, back: () -> Unit) {
    Column {
        Header("Historial")
        if (items.isEmpty()) Text("Todavía no hay consultas guardadas.", color = Muted, modifier = Modifier.padding(20.dp))
        LazyColumn(Modifier.padding(horizontal = 20.dp).weight(1f)) { items(items) { (e,r) -> Card(Modifier.fillMaxWidth().padding(vertical = 5.dp), colors = CardDefaults.cardColors(containerColor = Card)) { Column(Modifier.padding(16.dp)) { Text(e, color = Color.White); Text("→ $r", color = Red, fontWeight = FontWeight.Bold) } } } }
        OutlinedButton(back, Modifier.fillMaxWidth().padding(20.dp)) { Text("Volver") }
    }
}

private fun copy(context: Context, text: String) {
    (context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("ERC", text))
    Toast.makeText(context, "Copiado", Toast.LENGTH_SHORT).show()
}

private fun launchErcCalc(context: Context) {
    val pm = context.packageManager
    val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    val match = pm.queryIntentActivities(query, 0).firstOrNull {
        val label = it.loadLabel(pm).toString().lowercase()
        label == "erc calc" || label.contains("erc calc")
    }
    if (match != null) {
        pm.getLaunchIntentForPackage(match.activityInfo.packageName)?.let { context.startActivity(it); return }
    }
    Toast.makeText(context, "No encontré ERC Calc instalada. Abre ERC Calc manualmente y pega el ERC copiado.", Toast.LENGTH_LONG).show()
}
