# Unlock Radio Japonés JM — MVP v2

Aplicación Android en Kotlin + Jetpack Compose.

## Implementado
- Identidad oscura/roja de Unlock Radio Japonés JM.
- Buscador de modelos.
- NSZT-W62G con tutorial fotográfico real aportado por el propietario del proyecto.
- Validación ERC: 16 caracteres hexadecimales.
- Copiar ERC y abrir ERC Calc instalada (si Android la encuentra por nombre).
- Registro manual del resultado de 8 caracteres.
- Instrucción final específica del NSZT-W62G para escribir el resultado y pulsar 「完了」.
- Historial de la sesión.
- Otros modelos visibles quedan marcados como tutorial en preparación y no permiten continuar para evitar instrucciones incorrectas.

## Probar
Abrir esta carpeta en Android Studio, esperar la sincronización de Gradle y ejecutar en un teléfono Android o emulador.

## Nota
ERC Calc es una aplicación externa. Este proyecto no contiene ni copia su algoritmo; el MVP copia el ERC al portapapeles e intenta abrir la aplicación instalada.
